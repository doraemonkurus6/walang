const { main } = require("./src");

main().catch((err) => console.error(err));
